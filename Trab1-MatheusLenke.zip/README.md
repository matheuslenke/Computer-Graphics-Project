# Instruções para rodar aplicação

Obs: Testado no Ubuntu!!!

```bash
    # Compila aplicação
    make
    
    # Roda executável indicando arquivo svg da arena
    ./run arenas/arena_teste.svg

    # Compila e roda a aplicação indicando arquivo da arena
    make run FILE=arenas/arena_teste.svg 
```